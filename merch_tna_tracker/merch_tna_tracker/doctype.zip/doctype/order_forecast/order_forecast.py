# Copyright (c) 2026, Merch TNA Tracker and contributors
# For license information, please see license.txt

import sys

import frappe
from frappe import _
from frappe.model.base_document import get_controller
from frappe.model.document import Document
from frappe.utils import flt, get_first_day, getdate, today

# A forecast in one of these statuses still has projected volume left.
ACTIVE_STATUSES = ("Open", "Partly Confirmed")


def call_helper(doctype, function_name, *args):
	"""Call a helper that lives next to another DocType's controller, without needing the app name."""
	module = sys.modules[get_controller(doctype).__module__]
	return getattr(module, function_name)(*args)


def get_buyer_group(buyer):
	"""A brand under a bigger buyer counts as part of that buyer (Merch Buyer.buyer_group)."""
	return frappe.db.get_value("Merch Buyer", buyer, "buyer_group") or buyer


def get_order_totals(forecast):
	"""(confirmed qty, cancelled qty) of the Order Lines that come from this forecast.

	Confirmed is what is still wanted (net qty). Cancelled is what the buyer cancelled, partly or fully.
	"""
	if not forecast or not frappe.db.table_exists("Order Line"):
		return 0.0, 0.0

	confirmed, cancelled = frappe.db.sql(
		"""
		select coalesce(sum(coalesce(net_qty, qty)), 0), coalesce(sum(cancelled_qty), 0)
		from `tabOrder Line`
		where forecast = %s
		""",
		forecast,
	)[0]
	return flt(confirmed), flt(cancelled)


def calculate_progress(qty, value, value_usd, dropped_qty, confirmed_qty, order_cancelled_qty):
	"""Projected qty = confirmed + cancelled + remaining. Used on save and when an Order Line changes."""
	qty = flt(qty)
	confirmed = flt(confirmed_qty)
	cancelled = flt(dropped_qty) + flt(order_cancelled_qty)
	remaining = max(qty - confirmed - cancelled, 0.0)

	if remaining > 0:
		status = "Partly Confirmed" if confirmed > 0 else "Open"
	else:
		status = "Confirmed" if confirmed > 0 else "Cancelled"

	ratio = remaining / qty if qty else 0.0
	return {
		"status": status,
		"confirmed_qty": confirmed,
		"cancelled_qty": cancelled,
		"remaining_qty": remaining,
		"remaining_value": flt(flt(value) * ratio, 2),
		"remaining_value_usd": flt(flt(value_usd) * ratio, 2),
	}


def update_forecast_progress(forecast):
	"""Called from Order Line whenever a line linked to a forecast is saved, changed or deleted."""
	if not forecast:
		return

	row = frappe.db.get_value(
		"Order Forecast", forecast, ["qty", "value", "value_usd", "dropped_qty"], as_dict=True
	)
	if not row:
		return

	confirmed, order_cancelled = get_order_totals(forecast)
	progress = calculate_progress(row.qty, row.value, row.value_usd, row.dropped_qty, confirmed, order_cancelled)
	frappe.db.set_value("Order Forecast", forecast, progress, update_modified=False)


class OrderForecast(Document):
	def validate(self):
		self.set_currency()
		self.set_month()
		self.set_amounts()
		self.set_progress()
		self.validate_duplicate()
		self.warn_if_past_month()

	def set_currency(self):
		currency = frappe.db.get_value("Merch Buyer", self.buyer, "order_currency")
		if not currency:
			frappe.throw(
				_("Please set Order Currency on buyer {0} first.").format(
					frappe.get_desk_link("Merch Buyer", self.buyer)
				)
			)
		self.currency = currency

	def set_month(self):
		if not self.forecast_month:
			frappe.throw(_("Forecast Month is required."))

		# Any day of the month can be picked; it is always saved as the 1st.
		self.forecast_month = get_first_day(self.forecast_month)

	def set_amounts(self):
		if flt(self.qty) <= 0:
			frappe.throw(_("Qty must be greater than zero."))

		self.value = flt(self.value, 2)

		if self.currency == "USD":
			rate = 1.0
		else:
			rate = flt(call_helper("Order Book Settings", "get_eur_to_usd_rate"), 4)
		self.value_usd = flt(self.value * rate, 2)

		if self.value <= 0:
			frappe.msgprint(_("No value entered, so Value USD is 0."), indicator="orange", alert=True)

	def set_progress(self):
		confirmed, order_cancelled = get_order_totals(self.name)
		dropped = flt(self.dropped_qty)

		if dropped < 0:
			frappe.throw(_("Cancelled from Projection cannot be negative."))

		# Only what has not been ordered or cancelled yet can still be cancelled from the projection.
		left = max(flt(self.qty) - confirmed - order_cancelled, 0.0)
		if dropped > left:
			frappe.throw(
				_("Only {0} of this forecast is left to cancel. Confirmed: {1}, cancelled orders: {2}.").format(
					frappe.bold(int(left)), int(confirmed), int(order_cancelled)
				)
			)

		self.dropped_qty = dropped
		self.update(
			calculate_progress(self.qty, self.value, self.value_usd, dropped, confirmed, order_cancelled)
		)

	def validate_duplicate(self):
		"""One active forecast per buyer and month, otherwise the Summary would count it twice."""
		if self.status not in ACTIVE_STATUSES:
			return

		duplicate = frappe.db.exists(
			"Order Forecast",
			{
				"buyer": self.buyer,
				"forecast_month": self.forecast_month,
				"status": ["in", ACTIVE_STATUSES],
				"name": ["!=", self.name],
			},
		)
		if duplicate:
			frappe.throw(
				_("{0} already has an active forecast for this month: {1}. Edit it instead of adding another one.").format(
					frappe.bold(self.buyer), frappe.get_desk_link("Order Forecast", duplicate)
				)
			)

	def warn_if_past_month(self):
		if self.status in ACTIVE_STATUSES and getdate(self.forecast_month) < get_first_day(getdate(today())):
			frappe.msgprint(
				_("This forecast is for a past month. Use Cancel Remaining if the rest will not come."),
				indicator="orange",
				alert=True,
			)
