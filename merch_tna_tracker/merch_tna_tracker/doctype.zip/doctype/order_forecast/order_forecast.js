// Copyright (c) 2026, Merch TNA Tracker and contributors
// For license information, please see license.txt

frappe.ui.form.on("Order Forecast", {
	refresh(frm) {
		if (frm.is_new() || flt(frm.doc.remaining_qty) <= 0) {
			return;
		}

		// Cancels everything that is still projected (not confirmed and not cancelled yet).
		frm.add_custom_button(__("Cancel Remaining"), () => {
			frappe.confirm(
				__("Cancel the remaining {0} pcs of this forecast?", [cint(frm.doc.remaining_qty)]),
				() => {
					frm.set_value("dropped_qty", flt(frm.doc.dropped_qty) + flt(frm.doc.remaining_qty));
					frm.save();
				}
			);
		});
	},
});
