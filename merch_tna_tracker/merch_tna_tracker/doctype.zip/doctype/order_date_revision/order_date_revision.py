# Copyright (c) 2026, Merch TNA Tracker and contributors
# For license information, please see license.txt

from frappe.model.document import Document


class OrderDateRevision(Document):
	# Child table: Frappe does not run validate() on child rows by itself.
	# Its rules (numbering, changed_by, no repeated date, history locked) live in
	# Order Line.validate(), which is where the parent's dates are available.
	pass
