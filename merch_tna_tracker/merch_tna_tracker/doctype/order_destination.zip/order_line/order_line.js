// Copyright (c) 2026, Merch TNA Tracker and contributors
// For license information, please see license.txt

frappe.ui.form.on("Order Line", {
	setup(frm) {
		// Only forecasts that still have something left. The server also checks the buyer.
		frm.set_query("forecast", () => {
			return { filters: { status: ["in", ["Projected", "Partly Confirmed"]] } };
		});
	},

	qty(frm) {
		set_amount(frm);
	},

	unit_price(frm) {
		set_amount(frm);
	},
});

// Preview only. The server recalculates Amount, Exchange Rate and Amount USD when you save.
function set_amount(frm) {
	frm.set_value("amount", flt(frm.doc.qty) * flt(frm.doc.unit_price));
}
